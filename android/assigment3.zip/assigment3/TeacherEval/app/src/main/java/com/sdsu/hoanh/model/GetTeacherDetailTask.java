package com.sdsu.hoanh.model;

import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.util.Log;

import com.sdsu.hoanh.teachereval.AllTeachersViewListener;
import com.sdsu.hoanh.teachereval.TeacherDetailViewListener;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

/**
 * async task for retrieve the detail of a teacher
 */
class GetTeacherDetailTask extends AsyncTask<String, Integer, String> {

    protected TeacherDetailViewListener _callback;

    public GetTeacherDetailTask(TeacherDetailViewListener callback)
    {
        _callback = callback;
    }

    /**
     * Issue a REST call
     * @param urls
     * @return
     */
    protected String doInBackground(String... urls ) {
        String urlToGetTeacherDetail = urls[0];

        HttpClient httpClnt  = AndroidHttpClient.newInstance(null);
        HttpGet get = new HttpGet(urlToGetTeacherDetail);
        try
        {
            ResponseHandler<String> rsp = new BasicResponseHandler();
            String body = httpClnt.execute(get, rsp);
            return body;
        }
        catch(Exception anyException)
        {
            Log.e("Teacher Detail", "Got unexpected exception " + anyException.getMessage());
        }
        return null;
    }

    /**
     * convert json of the following format to Teacher
     * '{
     *   "id":2,
     *   "office":"GMCS 407B",
     *   "phone":"619-594-6191",
     *   "email":"beck@cs.sdsu.edu",
     *   "rating":
     *       {
     *          "average":5.0,
     *          "totalRatings":12
     *        },
     *   "firstName":"Dr. Leland",
     *   "lastName":"Beck"}'
     * @param oneTeacherJsonData
     * @return a valid teacher POJO
     */
    private Teacher jsonToTeacher(String oneTeacherJsonData)
    {
        Teacher teacher = null;
        try {
            JSONObject oneTeacherJson = new JSONObject(oneTeacherJsonData);

            String idStr = oneTeacherJson.getString(JsonKeys.ID_JSON_KEY);
            int id = Integer.parseInt(idStr);

            teacher = new Teacher();
            teacher.setId(id);
            teacher.setFirstName(oneTeacherJson.getString(JsonKeys.FIRST_NAME_JSON_KEY));
            teacher.setLastName(oneTeacherJson.getString(JsonKeys.LAST_NAME_JSON_KEY));

            teacher.setPhone(oneTeacherJson.getString(JsonKeys.PHONE_JSON_KEY));
            teacher.setOfficeHr(oneTeacherJson.getString(JsonKeys.OFFICE_JSON_KEY));
            teacher.setEmail(oneTeacherJson.getString(JsonKeys.EMAIL_JSON_KEY));

            // extract the rating
            JSONObject ratingJsonObj = oneTeacherJson.getJSONObject(JsonKeys.RATING_JSON_KEY);

            String doubleStr = ratingJsonObj.getString(JsonKeys.TOTAL_RATING_JSON_KEY);
            teacher.setTotalRating(Double.parseDouble(doubleStr));

            doubleStr = ratingJsonObj.getString(JsonKeys.AVERAGE_RATING_JSON_KEY);
            teacher.setAveRating(Double.parseDouble(doubleStr));

        }
        catch(JSONException jsonException)
        {
            Log.e("Teacher", "Unable to parse json array " + oneTeacherJsonData
                    + ".  Exception " + jsonException.getMessage());
        }

        return teacher;
    }
    protected void onProgressUpdate(Integer... progress) {
        //setProgressPercent(progress[0]);
    }

    protected void onPostExecute(String json) {
        Teacher teacherDetail = jsonToTeacher(json);
        _callback.onTeacherDetail(teacherDetail);
    }

}
