package com.sdsu.hoanh.teachereval;

import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.content.Intent;
import android.view.View;
import android.widget.ListView;

import com.sdsu.hoanh.model.Teacher;
import com.sdsu.hoanh.model.TeacherModel;

import java.util.ArrayList;
import java.util.List;


/**
 * This fragment shows the listing of teachers
 */
public class TeacherListFragment extends ListFragment implements  AllTeachersViewListener {

    // singleton model
    private TeacherModel model = TeacherModel.getInstance();

    // collection of teacher retrieved from the service
    private List<Teacher> teachers = null;

    /**
     * The creation method
     */
    @Override
    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);

        // call the model to get the teachers async and invoke callback into this class.
        model.getTeachersAsync(this);

    }

    /**
     * setup the listview and its listener.
     * @param bundle
     */
    @Override
    public void onActivityCreated(Bundle bundle)
    {
        super.onActivityCreated(bundle);
        ListView lv = this.getListView();

        lv.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        // Setting the item click listener for listView
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Teacher selTeacher = teachers.get(position);

                // launch the detail activity
                TeacherListFragment.this._showDetail(selTeacher);
            }
        });

        this.registerForContextMenu(lv);

    }

    /**
     * Navigation to date activity
     */
    private void _showDetail(Teacher selTeacher)
    {
        Intent intent = new Intent(this.getActivity(), TeacherDetailActivity.class);
        intent.putExtra(TeacherDetailActivity.SelectedTeacherIdKey, selTeacher.getId());
        this.startActivity(intent);
    }

    /**
     * Callback from model.
     * @param availableTeachers
     */
    @Override
    public void onTeachers(List<Teacher> availableTeachers) {
        // save the teachers
        this.teachers = availableTeachers;

        // generate an array of teach names
        List<String> teacherNames = new ArrayList<>();
        for(Teacher teacher : availableTeachers)
        {
            teacherNames.add(generateFullName(teacher.getFirstName(), teacher.getLastName()));
        }

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this.getActivity(),
                android.R.layout.simple_list_item_checked,
                teacherNames);

        this.setListAdapter(dataAdapter);
    }

    private static String generateFullName(String first, String last)
    {
        return first + " " + last;
    }
}
