package com.sdsu.hoanh.model;


/**
 * The keys for the json data from the remote REST end point
 */
public final class JsonKeys {
    public final static String ID_JSON_KEY ="id";
    public final static String FIRST_NAME_JSON_KEY = "firstName";
    public final static String LAST_NAME_JSON_KEY = "lastName";
    public final static String PHONE_JSON_KEY = "phone";
    public final static String OFFICE_JSON_KEY = "office";
    public final static String EMAIL_JSON_KEY = "email";
    public final static String RATING_JSON_KEY = "rating";
    public final static String AVERAGE_RATING_JSON_KEY = "average";
    public final static String TOTAL_RATING_JSON_KEY = "totalRatings";
    public final static String COMMENT_TEXT_JSON_KEY = "text";
    public final static String COMMENT_DATE_JSON_KEY = "date";

}
