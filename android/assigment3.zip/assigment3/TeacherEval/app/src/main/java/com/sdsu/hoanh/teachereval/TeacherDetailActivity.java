package com.sdsu.hoanh.teachereval;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

/**
 * A container of the teacher detail fragment.
 */
public class TeacherDetailActivity extends ActionBarActivity {

    static public final String SelectedTeacherIdKey = "SelectedTeacherId";
    static public final String SelectedTeacherNameKey = "SelectedTeacherName";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_detail);

        int teacherId = getIntent().getIntExtra(SelectedTeacherIdKey, -1);

        _loadTeacherDetailFragment(teacherId);
    }
    /**
     * create the teachers fragment.
     */
    private void _loadTeacherDetailFragment(int teacherId)
    {
        TeacherDetailFragment frag = TeacherDetailFragment.newInstance(teacherId);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.frag_host, frag)
                .commit();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_teacher_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
