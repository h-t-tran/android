package com.sdsu.hoanh.teachereval;

import com.sdsu.hoanh.model.Teacher;

import java.util.List;

/**
 * Callback interface to notify client of a listing of all teachers
 */
public interface AllTeachersViewListener {
    /**
     * notify client of all available teachers
     * @param teachers a collection of teachers.
     */
    void onTeachers(List<Teacher> teachers);
}
