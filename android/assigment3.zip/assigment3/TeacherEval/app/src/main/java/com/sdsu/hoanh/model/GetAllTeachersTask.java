package com.sdsu.hoanh.model;

import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.util.Log;

import com.sdsu.hoanh.teachereval.AllTeachersViewListener;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Async task to retrieve all the teachers from the service.
 */
class GetAllTeachersTask extends AsyncTask<String, Integer, String> {

    private AllTeachersViewListener _callback;

    public GetAllTeachersTask(AllTeachersViewListener callback)
    {
        _callback = callback;
    }

    protected String doInBackground(String... urls ) {
        String urlToGetAllTeachers = urls[0];

        HttpClient httpClnt  = AndroidHttpClient.newInstance(null);
        HttpGet get = new HttpGet(urlToGetAllTeachers);
        try
        {
            ResponseHandler<String> rsp = new BasicResponseHandler();
            String body = httpClnt.execute(get, rsp);
            return body;

        }
        catch(Exception anyException)
        {
            Log.e("All Teacher", "Got unexpected exception " + anyException.getMessage());
        }
        return null;
    }

    /**
     * Convert the json string to a list of teachers
     */
    private List<Teacher> jsonToTeachers(String jsonArray)
    {
        List<Teacher> teachers = new ArrayList<Teacher>();

        try {
            JSONArray teacherJsonArray = new JSONArray(jsonArray);
            for(int teacherIdx = 0; teacherIdx < teacherJsonArray.length(); teacherIdx++)
            {
                JSONObject teacherJsonObject = teacherJsonArray.getJSONObject(teacherIdx);

                // {"id":1,"firstName":"Ivan","lastName":"Bajic"}
                int id = teacherJsonObject.getInt(JsonKeys.ID_JSON_KEY);
                String firstname = teacherJsonObject.getString(JsonKeys.FIRST_NAME_JSON_KEY);
                String lastname = teacherJsonObject.getString(JsonKeys.LAST_NAME_JSON_KEY);
                Teacher teacher = new Teacher();
                teacher.setId(id);
                teacher.setFirstName(firstname);
                teacher.setLastName(lastname);
                teachers.add(teacher);
            }
        }
        catch(JSONException jsonException)
        {
            Log.e("Teacher", "Unable to parse json array " + jsonArray
                    + ".  Exception " + jsonException.getMessage());
        }

        return teachers;
    }
    protected void onProgressUpdate(Integer... progress) {

    }

    protected void onPostExecute(String json) {

        // convert json to teacher then invoke the callback.
        List<Teacher> teachers = jsonToTeachers(json);
        _callback.onTeachers(teachers);
    }

}
