package com.sdsu.hoanh.teachereval;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.sdsu.hoanh.model.Teacher;
import com.sdsu.hoanh.model.TeacherModel;

import java.util.List;


public class AddRatingActivity extends ActionBarActivity {

    private int _teacherId;
    private String _teacherName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_rating);

        _teacherId = getIntent().getIntExtra(TeacherDetailActivity.SelectedTeacherIdKey, -1);
        _teacherName = getIntent().getStringExtra(TeacherDetailActivity.SelectedTeacherNameKey);


        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.container, AddRatingFragment.newInstance(_teacherId, _teacherName))
                    .commit();
        }
    }


//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_add_rating, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class AddRatingFragment extends Fragment {
        private static final String TEACHER_ID_KEY = "TEACHER_ID_KEY";
        private static final String TEACHER_NAME_KEY = "TEACHER_NAME_KEY";

        private int _teacherId;
        private String _teacherName;
        /**
         * Factory method to create the fragment
         * @param teacherId
         * @return
         */
        public static AddRatingFragment newInstance(int teacherId, String teacherName) {
            AddRatingFragment fragment = new AddRatingFragment();
            Bundle bundleOfDataToFrag = new Bundle();
            bundleOfDataToFrag.putInt(TEACHER_ID_KEY, teacherId);
            bundleOfDataToFrag.putString(TEACHER_NAME_KEY, teacherName);
            fragment.setArguments(bundleOfDataToFrag);
            return fragment;
        }

        public AddRatingFragment() {
            // Required empty public constructor
        }

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

            Bundle inputArgBundle = getArguments();

            if (inputArgBundle != null) {
                _teacherId = inputArgBundle.getInt(TEACHER_ID_KEY);
                _teacherName = inputArgBundle.getString(TEACHER_NAME_KEY);

            }
        }
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_add_rating, container, false);
            return rootView;
        }

        @Override
        public void onActivityCreated(Bundle bundle) {
            super.onActivityCreated(bundle);

            View view= getView();

            // register a add rating button listener
            Button ratingButton = (Button)view.findViewById(R.id.buttonSubmitNewRating);
            ratingButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    AddRatingFragment.this.submitRating();
                }
            });

            // display the prompt to user as to who he is rating
            final TextView promptTextView = (TextView) view.findViewById(R.id.textViewPleaseRate);
            promptTextView.setText("Please rate " + _teacherName + "(" +_teacherId + ")");
        }

        /**
         * retrieve the selected stars and comment to submit the rating to the model.
         */
        private void submitRating()
        {
            View view= getView();
            final RatingBar  newRating = (RatingBar) view.findViewById(R.id.ratingBarNewRating);
            final TextView newComment = (TextView) view.findViewById(R.id.editTextNewComment);
            String comment = newComment.getText().toString();

            // round down the rating
            int numStars = (int)newRating.getRating();
            if(numStars == 0 && comment.isEmpty())
            {
                showToast("Please enter a rating or a comment");
            }
            else {

                // ask the model to submit the rating
                TeacherModel.getInstance().submitRating(_teacherId, numStars, comment,
                        new TeacherDetailViewListener() {
                            public void onTeacherDetail(Teacher teacher) {
                                // do nothing
                            }

                            public void onTeacherComments(int teacherId, List<String> allComments) {
                                // do nothing
                            }

                            public void onNewRatingSubmitResult(int teacherId, boolean success) {

                                // display a success toast and exit this activity
                                AddRatingFragment.this.displaySubmissionResult(success);

                                Intent intent = new Intent();
                                AddRatingFragment.this.getActivity().setResult(RESULT_OK, intent);

                                // return this activity
                                AddRatingFragment.this.getActivity().finish();
                            }

                        });

            }
        }

        /**
         * Display a postive or negative toast indicate if the submission is success or not.
         * @param success true if the operation is successful, false otherwise
         */
        private void displaySubmissionResult(boolean success)
        {
            showToast(success ?"Your rating has been submitted.":
                    "The submission failed.");
        }

        private void showToast(String toastMessage)
        {
            Toast.makeText(this.getActivity(), toastMessage, Toast.LENGTH_SHORT).show();
        }

    }
}
