package com.sdsu.hoanh.teachereval;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

import com.sdsu.hoanh.model.Teacher;
import com.sdsu.hoanh.model.TeacherModel;

import java.util.List;

/**
 * Display the detail of the selected teacher.
 */
public class TeacherDetailFragment extends Fragment {

    private static final String TEACHER_ID_KEY = "TEACHER_ID_KEY";

    private int _teacherId;
    private TeacherModel model = TeacherModel.getInstance();
    private OnFragmentInteractionListener mListener;
    private Teacher _retrievedTeacher = null;


    /**
     * Factory method to create the fragment
     * @param teacherId
     * @return
     */
    public static TeacherDetailFragment newInstance(int teacherId) {
        TeacherDetailFragment fragment = new TeacherDetailFragment();
        Bundle bundleOfDataToFrag = new Bundle();
        bundleOfDataToFrag.putInt(TEACHER_ID_KEY, teacherId);
        fragment.setArguments(bundleOfDataToFrag);
        return fragment;
    }

    public TeacherDetailFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle inputArgBundle = getArguments();

        if (inputArgBundle != null) {
            _teacherId = inputArgBundle.getInt(TEACHER_ID_KEY);
            getTeacherDetail();
            getAllComments(true); // pass in true since we want to use cache if possible
        }

    }

    private void getTeacherDetail() {

        // ask the model for the teacher detail
        model.getTeacherDetailAsync(_teacherId, new TeacherDetailViewListener()
        {
            public void onNewRatingSubmitResult(int teacherId, boolean success) {
                // do nothing
            }

            public void onTeacherDetail(Teacher teacher)
            {
                updateTeacherDetail(teacher);
            }

            public void onTeacherComments(int teacherId, List<String> allComments)
            {
                // do nothing
            }
        });
    }

    /**
     * Retrieve all the comments for the selected teacher
     * @param useCache indicates if we are to use the cache (if it exist) or not.
     */
    private void getAllComments(boolean useCache) {
        // retrieve comments
        model.getTeacherCommentsAsync(_teacherId, new TeacherDetailViewListener() {
            public void onTeacherDetail(Teacher teacher) {
                // do mothing
            }

            public void onTeacherComments(int teacherId, List<String> allComments) {
                updateAllComments(allComments);
            }
            public void onNewRatingSubmitResult(int teacherId, boolean success) {
                // do nothing
            }

        }, useCache);
    }

    /**
     * Display the view to allow selection of star and input comments
     */
    private void goToRatingActivity()
    {
        Intent intent = new Intent(this.getActivity(), AddRatingActivity.class);
        intent.putExtra(TeacherDetailActivity.SelectedTeacherIdKey, _teacherId);
        intent.putExtra(TeacherDetailActivity.SelectedTeacherNameKey,
                _retrievedTeacher.getFirstName() + " " + _retrievedTeacher.getLastName());

        // start with an expected result so we could refresh the comment and star rating when
        // rating submission activity results.
        startActivityForResult(intent, 0);

    }
    /**
     * invoked from the rating submission activity.  We want to refresh everything
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == Activity.RESULT_OK)
        {
            getTeacherDetail();
            getAllComments(false);  // pass in false to not use the cache since we want to
                                    // get the latest comments
        }
    }

    /**
     * display all the comments to the view
     * @param allComments a list of all comments
     */
    private void updateAllComments(List<String> allComments) {

        StringBuilder allCommentsStr = new StringBuilder();
        for(String aComment : allComments)
        {
            allCommentsStr.append(aComment);
            allCommentsStr.append("\n");  // new line
        }

        View view= getView();
        TextView commentTextView = (TextView)view.findViewById(R.id.tvComments);
        commentTextView.setText(allCommentsStr.toString());
    }

    /**
     * display the detail of the selected teacher
     */
    private void updateTeacherDetail(Teacher teacher)
    {
        _retrievedTeacher = teacher;
        View view= getView();
        RatingBar currRating = (RatingBar) view.findViewById(R.id.currRatingBar);
        currRating.setRating((float)teacher.getAveRating());

        TextView fullNameTextview = (TextView) view.findViewById(R.id.tvName);
        fullNameTextview.setText(teacher.getFirstName() + " " + teacher.getLastName());

        TextView phoneTextview = (TextView) view.findViewById(R.id.tvPhone);
        phoneTextview.setText(teacher.getPhone());

        TextView officeTextview = (TextView) view.findViewById(R.id.tvLocation);
        officeTextview.setText(teacher.getOfficeHr());

        TextView emailTextView = (TextView)view.findViewById(R.id.tvEmail);
        emailTextView.setText(teacher.getEmail());

    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        View view= getView();
        RatingBar currRating = (RatingBar) view.findViewById(R.id.currRatingBar);

        // disable the rating bar as it's readonly.
        currRating.setEnabled(false);


        // register a add rating button listener
        Button ratingButton = (Button)view.findViewById(R.id.btnRating);
        ratingButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TeacherDetailFragment.this.goToRatingActivity();

            }
        });

        TextView commentTextView = (TextView)view.findViewById(R.id.tvComments);
        // enable scrolling of the comment text view
        commentTextView.setMovementMethod(new ScrollingMovementMethod());

    }

        @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_teacher_detail, container, false);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }

}
