package com.sdsu.hoanh.model;

import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.util.Log;

import com.sdsu.hoanh.teachereval.TeacherDetailViewListener;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Async task to retrieve all comments for a teacher
 */
class GetTeacherCommentTask extends AsyncTask<String, Integer, String> {

    /**
     * protected since it's being access by subclass
     */
    protected TeacherDetailViewListener _callback;
    protected int _teacherId;
    public GetTeacherCommentTask(int teacherId, TeacherDetailViewListener callback)
    {
        _callback = callback;
        _teacherId = teacherId;
    }

    /**
     * Issue a REST call
     * @param urls
     * @return
     */
    protected String doInBackground(String... urls ) {
        String urlToGetTeacherComments = urls[0];

        HttpClient httpClnt  = AndroidHttpClient.newInstance(null);
        HttpGet get = new HttpGet(urlToGetTeacherComments);
        try
        {
            ResponseHandler<String> rsp = new BasicResponseHandler();
            String body = httpClnt.execute(get, rsp);
            return body;
        }
        catch(Exception anyException)
        {
            Log.e("Teacher Detail", "Got unexpected exception while retrieve comments " + anyException.getMessage());
        }
        return null;
    }

    /**
     * convert json of the following format to Teacher
     *  '[
     *      {
     *          "text":"Good Instructor",
     *          "date":"10/26/11"},
     *          {"text":"doit","date":"10/25/11"
     *      },
     *      {
     *          "text":"cat",
     *          "date":"10/24/11"
     *      },
     *      {
     *          "text":"He iscold",
     *          "date":"10/24/11"
     *      },
     *      {
     *              "text":"He is hot",
     *              "date":"10/24/11"
     *       }]'

     * @param allCommentsJsonData
     * @return a valid teacher POJO
     */
    private List<String> jsonToCommentArray(String allCommentsJsonData)
    {
        List<String> resultingComments = new ArrayList<String>();

        Teacher teacher = null;
        try {
            JSONArray allCommentsJson = new JSONArray(allCommentsJsonData);
            for(int eachJsonItemIdx = 0; eachJsonItemIdx < allCommentsJson.length(); eachJsonItemIdx++ ) {
                JSONObject oneComment = allCommentsJson.getJSONObject(eachJsonItemIdx);

                String text = oneComment.getString(JsonKeys.COMMENT_TEXT_JSON_KEY);
                String date = oneComment.getString(JsonKeys.COMMENT_DATE_JSON_KEY);
                resultingComments.add(date + " " + text);

            }

        }
        catch(JSONException jsonException)
        {
            Log.e("Teacher", "Unable to parse json array " + allCommentsJsonData
                    + ".  Exception " + jsonException.getMessage());
        }

        return resultingComments;
    }
    protected void onProgressUpdate(Integer... progress) {
        //setProgressPercent(progress[0]);
    }

    protected void onPostExecute(String json) {

        List<String> callComments = jsonToCommentArray(json);
        _callback.onTeacherComments(this._teacherId, callComments);
    }

}
