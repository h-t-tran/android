package com.sdsu.hoanh.model;

import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.util.Log;

import com.sdsu.hoanh.teachereval.TeacherDetailViewListener;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * an async task to handler submitting of teacher rating
 */
class SubmitTeacherRatingTask extends AsyncTask<String, Integer, String> {

    private TeacherDetailViewListener _callback;
    private int _numStars;
    private String _comment;
    public SubmitTeacherRatingTask(int numStar, String comment, TeacherDetailViewListener callback)
    {
        _callback = callback;
        _numStars = numStar;
        _comment = comment;
    }

    /**
     * Issue a REST call
     * @param urls
     * @return
     */
    protected String doInBackground(String... urls ) {
        String urlAddStarRating = urls[0];
        String urlAddComment = urls[1];

        // submit star rating only if it's not 0
        if(_numStars > 0) {
            submitStarRating(urlAddStarRating);
        }

        // submit comment only if it is not empty.
        if( ! _comment.isEmpty()) {
            submitComment(urlAddComment);
        }
        return "";
    }

    private void submitStarRating(String urlAddStarRating)
    {
        HttpClient httpClnt  = AndroidHttpClient.newInstance(null);

        HttpPost post = new HttpPost(urlAddStarRating);
        try
        {
            ResponseHandler<String> rsp = new BasicResponseHandler();
            String body = httpClnt.execute(post, rsp);

        }
        catch(Exception anyException)
        {
            Log.e("Teacher Detail", "Got unexpected exception " + anyException.getMessage());
        }
    }

    private void submitComment(String urlAddComment)
    {
        HttpClient httpClnt  = AndroidHttpClient.newInstance(null);

        HttpPost post = new HttpPost(urlAddComment);
        try
        {
            StringEntity comment = new StringEntity(_comment, HTTP.UTF_8);
            post.setHeader("Content-Type", "application/json;charset=UTF-8");
            post.setEntity(comment);
            HttpResponse responseBody = httpClnt.execute(post);
        }
        catch(Exception anyException)
        {
            Log.e("Teacher Detail", "Got unexpected exception " + anyException.getMessage());
        }
    }

    protected void onProgressUpdate(Integer... progress) {
        //setProgressPercent(progress[0]);
    }

    protected void onPostExecute(String anyString) {
        _callback.onNewRatingSubmitResult(0, true);
    }

}
