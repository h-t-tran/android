package com.sdsu.hoanh.model;

import com.sdsu.hoanh.teachereval.AllTeachersViewListener;
import com.sdsu.hoanh.teachereval.TeacherDetailViewListener;

import java.util.HashMap;
import java.util.List;

/**
 * The model which serves as the entry point to the data
 */
public class TeacherModel {
    public static final String PROJECT_NAME = "TeacherRating";


    private static TeacherModel _instance;
    private final static String _baseUrl = "http://bismarck.sdsu.edu/rateme/";
    private TeacherDatabaseHelper database;
    /**
     * cache all the teacher POCO including the detail.
     */
    private HashMap<Integer, Teacher> _teacherCache = new HashMap<Integer, Teacher>();

    /**
     * contain the cache of all teacher list initially.  These teachers poco only have
     * the first and lastname set.
     */
    private HashMap<Integer, Teacher> _teacherListOnlyCache = new HashMap<Integer, Teacher>();

    /**
     * Singleton pattern.
     * @return the singleton
     */
    public static TeacherModel getInstance()
    {
        if(_instance == null)
        {
            _instance = new TeacherModel();
        }

        return _instance;
    }

    private TeacherModel()
    {
        this.database = TeacherDatabaseHelper.createInstance(null);
    }
    public void getTeachersAsync(final AllTeachersViewListener callback)
    {
        GetAllTeachersTask task = new GetAllTeachersTask(new AllTeachersViewListener()
        {
            public void onTeachers(List<Teacher> teachers)
            {
                // save all teachers in cache and database
                for(Teacher teacher : teachers)
                {
                    _teacherListOnlyCache.put(new Integer(teacher.getId()), teacher);
                    TeacherModel.this.database.insertOrUpdateTeacher(teacher);
                }

                callback.onTeachers(teachers);
            }
        });
        //GetAllTeachersTask task = new GetAllTeachersTask(callback);
        String [] urls = { _baseUrl + "list" };
        task.execute(urls);
    }

    public void getTeacherCommentsAsync(int teacherId,
                       final TeacherDetailViewListener callbackToView,
                       boolean useCache)
    {
        // see if in cache. if so get it.
        if(useCache && this._teacherCache.containsKey(teacherId)) {
            Teacher matchTeacher = _teacherCache.get(teacherId);

            // must invoke the callback async.
            GetTeacherCommentCacheTask cacheTask = new GetTeacherCommentCacheTask(
                            matchTeacher.getId(), matchTeacher.getComment(), callbackToView);
            cacheTask.execute(new String[] {});

            // This does not work  since it's within
            // UI thread and we are doing callback to update UI.
            //callbackToView.onTeacherComments(teacherId, matchTeacher.getComment());
        }
        else
        {
            // create a task and pass in a callback interceptor to cache data.
            GetTeacherCommentTask task = new GetTeacherCommentTask(teacherId, new TeacherDetailViewListener() {
                public void onNewRatingSubmitResult(int teacherId, boolean success) {
                    // do nothing
                }

                public void onTeacherDetail(Teacher teacher) {
                    // do nothing
                }

                public void onTeacherComments(int teacherId, List<String> allComments)
                {
                    Teacher matchTeacher = _teacherCache.get(teacherId);

                    // replace the teacher current comments
                    matchTeacher.setComment(allComments);

                    // save only the first few comments to prevent database over populated
                    int lowerBound =  allComments.size() - Math.min(allComments.size(), 5);
                    for(int commentIdx = allComments.size() - 1;
                            commentIdx >= lowerBound; commentIdx -- )
                    {
                        TeacherModel.this.database.insertComment(matchTeacher.getId(), allComments.get(commentIdx));
                    }

                    // notify the view
                    callbackToView.onTeacherComments(teacherId, allComments);

                }
            });
            String[] urls = {
                                    _baseUrl + "comments/" + teacherId // retrieve teacher comments
                            };
            task.execute(urls);
        }
    }

    public void submitRating(int teacherId, int numStars, final String comment, final TeacherDetailViewListener callback)
    {
        SubmitTeacherRatingTask task = new SubmitTeacherRatingTask(numStars,
                                comment, new TeacherDetailViewListener()
        {
            public void onTeacherDetail(Teacher teacher) {
                // do nothing
            }

            public void onTeacherComments(int teacherId, List<String> allComments) {
                // do nothing
            }

            public void onNewRatingSubmitResult(int teacherId, boolean success) {

                // save new comment
                TeacherModel.this.database.insertComment(teacherId, comment);
                callback.onNewRatingSubmitResult(teacherId, success);
            }
        });

        String[] urls = {
                _baseUrl + "rating/" + teacherId + "/" + numStars,   // add stars
                _baseUrl + "comment/" + teacherId                    // add comment

                };
        task.execute(urls);
    }

    public void getTeacherDetailAsync(int teacherId, final TeacherDetailViewListener callback)
    {

        // see if in cache. if so get it.
        if(this._teacherCache.containsKey(teacherId)) {
            Teacher matchTeacher = _teacherCache.get(teacherId);
            GetTeacherDetailCacheTask cacheTask = new GetTeacherDetailCacheTask(matchTeacher, callback);
            cacheTask.execute(new String[] {});

            // This does not work  since it's within
            // UI thread and we are doing callback to update UI.
            //callback.onTeacherDetail(matchTeacher);
        }
        else
        {
            // create a task and pass in a callback interceptor to cache data.
            GetTeacherDetailTask task = new GetTeacherDetailTask(new TeacherDetailViewListener() {
                public void onTeacherDetail(Teacher teacher) {
                    // save to cache.
                    TeacherModel.this._teacherCache.put(new Integer(teacher.getId()), teacher);

                    callback.onTeacherDetail(teacher);

                    // update the teacher in database.
                    TeacherModel.this.database.insertOrUpdateTeacher(teacher);
                }

                public void onTeacherComments(int teacherId, List<String> allComments) {
                    // do nothing
                }

                public void onNewRatingSubmitResult(int teacherId, boolean success) {
                    // do nothing
                }

            });
            String[] urls = {_baseUrl + "instructor/" + teacherId};
            task.execute(urls);
        }
    }

    ///////////////////////////////////////////////////////////////////////////
    //
    //
    /**
     * this task represent a task whose job is to invoke the callback asynchronously.
     * It does not call out the actual REST.
     */
    private class GetTeacherDetailCacheTask extends GetTeacherDetailTask
    {
        private Teacher _cacheTeacher;
        public GetTeacherDetailCacheTask(Teacher cacheTeacher, TeacherDetailViewListener callback)
        {
            super(callback);
            _cacheTeacher = cacheTeacher;
        }

        protected String doInBackground(String... urls ) {
            return "";
        }

        protected void onPostExecute(String json) {
//            try {
//                Thread.sleep(500);  // give some detail
//            } catch(Exception e)
//            {}

            _callback.onTeacherDetail(_cacheTeacher);
        }
    }

    /**
     * this task represent a task whose job is to invoke the callback asynchronously.
     * It does not call out the actual REST.
     */
    private class GetTeacherCommentCacheTask extends GetTeacherCommentTask
    {
        private List<String> _cacheComments;
        public GetTeacherCommentCacheTask(int teacherId, List<String> cacheComments,
                TeacherDetailViewListener callback)
        {
            super(teacherId, callback);
            _cacheComments = cacheComments;
        }


        protected String doInBackground(String... urls ) {
            return "";
        }

        protected void onPostExecute(String json) {

            _callback.onTeacherComments(_teacherId, _cacheComments);
        }
    }
}
