package com.sdsu.hoanh.teachereval;

import com.sdsu.hoanh.model.Teacher;

import java.util.List;


/**
 * Callback to notify view client of new teacher.
 */
public interface TeacherDetailViewListener {

    /**
     * notify the teacher data is available
     * @param teacher - pojo containing the teacher data.
     */
    void onTeacherDetail(Teacher teacher);

    /**
     * notify the client of all the comments available for the specified teacher
     */
    void onTeacherComments(int teacherId, List<String> allComments);

    /**
     * Indicates the submission of the rating star and comment is successful or not
     */
    void onNewRatingSubmitResult(int teacherId, boolean success);
}
