package com.sdsu.hoanh.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

/**
 * A singleton database where we persist teachers.
 */
public class TeacherDatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "teacher10.sqlite";
    public static final int VERSION = 2;
    private static final String TEACHER_TABLE_NAME = "teacher";
    private static final String COMMENT_TABLE_NAME = "comment";

    private static final String  FIRSTNAME_COL = "firstname";
    private static final String  LASTNAME_COL = "lastname";
    private static final String  PHONE_COL = "phone";
    private static final String  EMAIL_COL = "email";
    private static final String  LOCATION_COL = "location";
    private static final String  AVE_RATING_COL = "ave_rating";
    private static final String  TOTAL_RATING_COL = "total_rating";
    private static final String  COMMENT_COL = "comment";
    private static final String  TEACHER_ID_COL = "teacher_id";

    private static TeacherDatabaseHelper _instance = null;

    /**
     * Create a singleton of the the database helper using the passed in contenxt
     * @return the TeacherDatabaseHelper singleton
     */
    public static TeacherDatabaseHelper createInstance(Context appContext)
    {
        if(_instance == null)
        {
            _instance = new TeacherDatabaseHelper(appContext);

        }
        return _instance;
    }

    private TeacherDatabaseHelper(Context appContext)
    {
        super(appContext, DB_NAME, null, VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {

            // CREATE TABLE IF NOT EXISTS

            // create teacher table
            String sqlCreateTeacherTable = "create table " +
                        TEACHER_TABLE_NAME +
                        " (_id integer primary key autoincrement, " +
                            FIRSTNAME_COL + " varchar(100), " +
                            LASTNAME_COL + " varchar(100), " +
                            PHONE_COL + " varchar(100), " +
                            LOCATION_COL + " varchar(100), " +
                            EMAIL_COL + " varchar(100), " +
                            AVE_RATING_COL+ " integer, " +
                            TOTAL_RATING_COL + " integer)";
            db.execSQL(sqlCreateTeacherTable);

            // create comment table.
            String sqlCreateCommentTable = "create table " +
                    COMMENT_TABLE_NAME +
                    " (_id integer primary key autoincrement, " +
                    TEACHER_ID_COL + " integer, " +
                    COMMENT_COL + " varchar(100))";
            db.execSQL(sqlCreateCommentTable);

        }
        catch(Exception e)
        {
            Log.e(TeacherModel.PROJECT_NAME, "Unable to create table " +
                    TEACHER_TABLE_NAME + ".  Error code " + e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    /**
     * Update the teacher metadata
     * @param teacher the teach where we need to update
     * @return the # of rows affected.  it should be one.
     */
    private long updateTeacher(Teacher teacher)
    {
        long rowsUpdated = -1;
        try {
            ContentValues content = getTeacherContentValues(teacher);
            String whereCondition = FIRSTNAME_COL + " = '" + teacher.getFirstName() + "' " +
                            " AND " +
                            LASTNAME_COL + " = '" + teacher.getLastName() + "'";
            rowsUpdated = getWritableDatabase().update(TEACHER_TABLE_NAME, content, whereCondition, null);
        }
        catch(Exception e)
        {
            Log.e(TeacherModel.PROJECT_NAME, "Unable to insert to table " +
                    TEACHER_TABLE_NAME + ".  Error code " + e.getMessage());
        }

        return rowsUpdated;
    }

    /**
     * insert or update the teacher if it already exist
     * @param teacher
     * @return
     */
    public boolean insertOrUpdateTeacher(Teacher teacher)
    {
        boolean success = false;

        // try update first.  If failed, then insert.
        if(updateTeacher(teacher) <= 0) {

            try {
                ContentValues content = getTeacherContentValues(teacher);

                // success if we get a valid primary key back
                success = getWritableDatabase().insert(TEACHER_TABLE_NAME, null, content) != -1;
            }
            catch (Exception e) {
                Log.e(TeacherModel.PROJECT_NAME, "Unable to insert to table " +
                        TEACHER_TABLE_NAME + ".  Error code " + e.getMessage());
            }
        }
        else
        {
            success = true;
        }
        return success;

    }
    /**
     * insert a comment for a teacher
     */
    public boolean insertComment(int teacher, String comment) {
        boolean success = false;
        try {
           ContentValues commentValues = getTeacherCommentContentValues(teacher, comment);

            // success if we get a valid primary key back
            success = getWritableDatabase().insert(COMMENT_TABLE_NAME, null, commentValues) != -1;
        }
        catch (Exception e) {
            Log.e(TeacherModel.PROJECT_NAME, "Unable to insert to table " +
                    TEACHER_TABLE_NAME + ".  Error code " + e.getMessage());
        }
        return success;
    }

    private ContentValues getTeacherCommentContentValues(int teacherId,  String comment) {
        ContentValues content = new ContentValues();
        content.put(TEACHER_ID_COL, teacherId);
        content.put(COMMENT_COL, comment);
        return content;
    }

    private ContentValues getTeacherContentValues(Teacher teacher) {
        ContentValues content = new ContentValues();
        content.put(FIRSTNAME_COL, teacher.getFirstName());
        content.put(LASTNAME_COL, teacher.getLastName());
        content.put(PHONE_COL, teacher.getPhone());
        content.put(LOCATION_COL, teacher.getOfficeHr());
        content.put(EMAIL_COL, teacher.getEmail());
        content.put(AVE_RATING_COL, teacher.getAveRating());
        content.put(TOTAL_RATING_COL, teacher.getTotalRating());
        return content;
    }

}
