package com.sdsu.hoanh.model;

import java.util.List;

/**
 * A POJO representing a teacher.
 */
public class Teacher {
    private int id;
    private String firstName;
    private String lastName;
    private String officeHr;
    private String phone;
    private String email;
    private double aveRating;
    private double totalRating;
    private List<String> comment;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }


    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    public String getOfficeHr() {
        return officeHr;
    }

    public void setOfficeHr(String officeHr) {
        this.officeHr = officeHr;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public double getAveRating() {
        return aveRating;
    }

    public void setAveRating(double aveRating) {
        this.aveRating = aveRating;
    }


    public  List<String> getComment() {
        return comment;
    }

    public void setComment( List<String> comment) {
        this.comment = comment;
    }

    public double getTotalRating() {

        return totalRating;
    }

    public void setTotalRating(double totalRating) {
        this.totalRating = totalRating;
    }


}
