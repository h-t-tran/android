package com.sdsu.hoanh.assignment2;

/**
 * The various constants used by the project.
 */
public class Constants {
    public static final int DATE_ACTIVITY_RESULT_CODE = 1;
    public static final int LIST_ACTIVITY_RESULT_CODE = DATE_ACTIVITY_RESULT_CODE + 1;

}
